package day2;

public class Exercise4 {

	public static void main(String[] args) {
		int number = 100;
		int result;
		
	    result = number+10;
	    
		int number1 = 100;
		int result1;
		
	    result1 = number1-10;
	   
		int number2 = 100;
		int result2;
		
	    result2 = number2*10;
	    
		int number3 = 100;
		int result3;
		
	    result3 = number3/10;
	  System.out.println("덧셈 연산의 결과 : " + result);
	  System.out.println("뺄셈 연산의 결과 : " + result1);
	  System.out.println("곱셈 연산의 결과 : " + result2);
	  System.out.println("나눗셈 연산의 결과 : " + result3);
	}

}
