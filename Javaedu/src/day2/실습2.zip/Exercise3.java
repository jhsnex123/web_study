package day2;

public class Exercise3 {

	public static void main(String[] args) {
		
		char name1 = '장' ;
		char name2 = '현' ;
		char name3 = '수' ;
		
		System.out.print(name1);
		System.out.print(name2);
		System.out.print(name3);
	}

}
