package day2;

public class AlphaTest {

	public static void main(String[] args) {
	double num = Math.random();
	System.out.println("추출된 숫자 : " +(int)(num*1+1));
	System.out.println('A');
	System.out.println("추출된 숫자 : " +(int)(num*3+1) );
	System.out.println('C');
	System.out.println("추출된 숫자 : "  +(int)(num*26+1) );
	System.out.println('Z');
	}

}
